package task03;

/**
 * This class represents a bank account Persons can deposit or withdraw money
 */
public class Account {

	/**
	 * Saves the number of this account
	 **/
	// TODO: Insert code here

	/**
	 * Saves the owner of this account
	 **/
	// TODO: Insert code here

	/**
	 * Saves the balance of this account
	 **/
	// TODO: Insert code here


	/**
	 * Initializes a newly created Account object
	 **/
	// TODO: Insert code here
	

	/**
	 * Initializes a newly created Account object Sets the balance of this account
	 * to zero
	 **/
	// TODO: Insert code here
	

	/**
	 * Returns the balance of this account
	 * @return balance
	 */
	// TODO: Insert code here
	

	/**
	 * Withdraw money and lower balance.  
	 * It is not possible to withdraw more money than available
	 */
	// TODO: Insert code here
	

	/**
	 * Deposit money and increase balance. Max. 10000 per deposit allowed.
	 */
	// TODO: Insert code here
	

	/**
	 * Returns a String representation of this account
	 * 
	 * @return "Account No <accountNumber> by <owner>, balance: <balance>"
	 */
	// TODO: Insert code here
	
	
	

}
