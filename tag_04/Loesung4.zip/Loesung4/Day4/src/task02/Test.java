package task02;

public class Test {

	public static void main(String[] args) {

		String text = "Das IST ein TEXT";
		System.out.println("Original text: " + text);

		if (text.isEmpty())	{ 
			System.out.println("Leerer Text.");
		} else 	{ 

			System.out.println("length of this text: " + text.length());

			if (text.length() > 5) {
				System.out.println("First 5 letters: " + text.substring(0,5));
			}

			String lowercaseText = text.toLowerCase();
			System.out.println("lowercase text: " + lowercaseText);

			System.out.println("Starts with 'das': " + lowercaseText.startsWith("das"));

			int positionOfDer = lowercaseText.indexOf("der");
			if (positionOfDer >= 0) {
				System.out.println("Contains 'der' at the position " + positionOfDer);
			} else {
				System.out.println("'der' does not occur in this text.");
			}
			
			boolean endsWithPunctuation = text.endsWith(".") || text.endsWith("!");
			if(!endsWithPunctuation) {
				text.concat(".");
			}


		}

	}

}
