package task01;

/**
 * This class represents a raccoon.
 * All raccoons are initially gray.
 */
public class Raccoon {

	  public String color = "gray";

	  /**
	   * Lets this raccoon sleep for a while
	   */
	  public void sleep() {
	    System.out.println("I'm sleeping!");
	  }
	  
	  /**
	   * Lets this raccoon eat a several times
	   * @param times positive integer number
	   */
	  public void eat(int times) {
	    for (int i=0; i<times; i++) {
	      System.out.println("I'm eating!");
	    }
	  }
	  
	  /**
	   * Returns the color of this raccoon
	   * @return color 
	   */
	  public String getColor() {
	    return this.color;
	  } 
	  
	  /**
	   * Sets the color of this raccoon 
	   * to a new value
	   * @param color 
	   */
	  public void setColor(String color) {
		  this.color = color;
	  }
	  
	}
