package task01;

public class Test {

	public static void main(String[] args) {
		
		Raccoon fluffy = new Raccoon();
        
	    fluffy.sleep();
	    fluffy.eat(5);
	    
	    fluffy.setColor("orange");
	    
	    String color = fluffy.getColor();
	    System.out.println("Fluffy's color is: " + color);

	}

}
