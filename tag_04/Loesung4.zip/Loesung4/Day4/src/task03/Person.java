package task03;

/**
 * This class represents a person 
 */
public class Person {

	private String name;
	private int age;
	private MaritalStatus maritalStatus;
	
	/**
	 * Initializes a newly created Person object
	 */
	public Person(String name, int age) {
		if(name.isEmpty()) {
			throw new IllegalArgumentException("name must contain at least one letter");
		} 
		if (age < 0 || age > 130) {
			throw new IllegalArgumentException("age must be between 0 and 130");			
		}
		this.name = name;
		this.age = age;
		this.maritalStatus = MaritalStatus.SINGLE;
	}
	
	/**
	 * Returns the name of this person
	 * @return this.name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Returns the age of this person
	 * @return this.age
	 */
	public int getAge() {
		return this.age;
	}
	
	/**
	 * Returns the marital status of this person
	 * @return this.maritalStatus
	 */
	public MaritalStatus getMaritalStatus() {
		return maritalStatus;
	}

	/**
	 * Sets the martal status of this person 
	 * to the value given
	 * @param maritalStatus
	 */
	public void setMaritalStatus(MaritalStatus maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	
	/**
	 * Lets this person become one year older
	 */
	public void celebrateBirthday() {
		System.out.println("Let's party!");
		this.age += 1;
	}
	
	/**
	 * Returns a String representation of this person
	 */
	public String toString() {
		return "(Person: " + this.getName() + "," + this.getAge() + ")";
	}
	
}
