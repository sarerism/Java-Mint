package task03;

public enum MaritalStatus {
	SINGLE, MARRIED, DIVORCED, WIDOWED
}
