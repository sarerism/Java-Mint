package task04;

import java.util.Optional;
/**
 * This class represents a Car with two seats 
 * a space for one suitcase.
 */
public class SmartCar {

	private int emptyWeight;
	private Optional<Person> driver;
	private Optional<Person> coDriver;
	private Optional<Suitcase> suitcase;
	
	/**
	 * Initializes a newly created SmartCar object
	 * This car is initially empty an weighs at least 800 kg
	 */
	public SmartCar(int emptyWeight) {
		if(emptyWeight < 800) {
			throw new IllegalArgumentException("SmartCar can not be lighter than 800kg");
		}
		this.emptyWeight = emptyWeight;
		this.driver = Optional.empty();
		this.coDriver = Optional.empty();
		this.suitcase = Optional.empty();
	}




	public Optional<Person> getDriver() {
		return driver;
	}

	public void setDriver(Optional<Person> driver) {
		this.driver = driver;
	}

	public Optional<Person> getCoDriver() {
		return coDriver;
	}
	
	public void setCoDriver(Optional<Person> coDriver) {
		this.coDriver = coDriver;
	}

	public Optional<Suitcase> getSuitcase() {
		return suitcase;
	}

	/**
	 * Adds suitcase to the trunk of this car
	 * if its dimensions are not too large
	 * @param suitcase dimensions must be lower than 80x90x45
	 */
	public void setSuitcase(Optional<Suitcase> suitcase) {
		if(suitcase.isPresent()) {
			Suitcase newSuitcase = suitcase.get();
			if(newSuitcase.getHeight() > 80 || newSuitcase.getWidth() > 90 || newSuitcase.getLength() > 45) {
				throw new IllegalArgumentException("The suitcase is too large for this car");
			}
		}
		this.suitcase = suitcase;
	}
	
	/**
	 * Returns empty weight of this car
	 * @return empty weight in kilograms
	 */
	public int getEmptyWeight() {
		return this.emptyWeight;
	}
	
	/**
	 * Caclulates the total weight of this car
	 * @return total weight in kilograms
	 */
	public int getTotalWeight() {
		
		int result = this.getEmptyWeight();
		
		if(this.getDriver().isPresent()) {
			Person firstPerson = this.getDriver().get();
			result += firstPerson.getWeight();
		}
		if(this.getCoDriver().isPresent()) {
			Person secondPerson = this.getCoDriver().get();
			result += secondPerson.getWeight();
		}
		if(this.getSuitcase().isPresent()) {
			Suitcase trunkContent = this.getSuitcase().get();
			result += trunkContent.getWeight();
		}
		return result;
	}

	

	
	
}
