package task04;

/**
 * This class represents a suitcase with three dimensions
 * (height, width, length) and an empty weight of 1.
 */
public class Suitcase {

	private int height;
	private int width;
	private int length;
	private int weight;
	
	/**
	 * Initializes a newly created Suitcase object
	 * @param height first diemnsion, must be positive
	 * @param width second diemnsion, must be positive
	 * @param length third diemnsion, must be positive
	 */
	public Suitcase(int height, int width, int length) {
		if(height <=0 || width <= 0 || length <= 0) {
			throw new IllegalArgumentException("dimensions must be positive");
		}
		this.height = height;
		this.width = width;
		this.length = length;
		this.weight = 1;
	}

	/**
	 * Returns the height of this suitcase
	 * @return height
	 */
	public int getHeight() {
		return height;
	}


	/**
	 * Returns the width of this suitcase
	 * @return width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Returns the length of this suitcase
	 * @return length
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Returns the weight of this suitcase
	 * @return weight
	 */
	public int getWeight() {
		return weight;
	}

	/**
	 * Fill this suitcase with items of a certain weight
	 * @param weight weigt of the items must be positive or zero
	 */
	public void fill(int weight) {
		if(weight < 0) {
			throw new IllegalArgumentException("Weight must be positive oder zero");
		}
		this.weight += weight;
	}
	
	/**
	 * Empty this suitcase, i.e. all items are removed
	 * and weight is set to empty weight.
	 */
	public void empty() {
		this.weight = 1;
	}
	
	
}
