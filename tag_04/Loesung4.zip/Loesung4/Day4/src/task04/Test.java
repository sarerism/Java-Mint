package task04;

import java.util.Optional;

public class Test {

	public static void main(String[] args) {
		
		Person paul = new Person("Paul",20,80);
		Person paula = new Person("Paula",19,80);
		Suitcase suitcase = new Suitcase(20,80,40);
		suitcase.fill(20);
		
		SmartCar smartCar = new SmartCar(1000);
		smartCar.setDriver(Optional.of(paul));
		smartCar.setCoDriver(Optional.of(paula));
		smartCar.setSuitcase(Optional.of(suitcase));
		
		System.out.println(smartCar.getTotalWeight());
		smartCar.setCoDriver(Optional.empty());
		
		/* Test Exceptions */
		
		// Person ronnie = new Person("Ronnie",20,-4);
		
		// Suitcase flatCase = new Suitcase(0,20,40);
		
		// suitcase.fill(-4);
		
		// Suitcase largeSuitCase = new Suitcase(90,90,90);
		// smartCar.setSuitcase(Optional.of(largeSuitCase));
		
		
	}

}
