package task04;

/**
 * This class represents a person 
 */
public class Person {

	private String name;
	private int age;
	private int weight;
	
	/**
	 * Initializes a newly created Person object
	 */
	public Person(String name, int age, int weight) {
		if(name.isEmpty()) {
			throw new IllegalArgumentException("name must contain at least one letter");
		} 
		if (age < 0 || age > 130) {
			throw new IllegalArgumentException("age must be between 0 and 130");			
		}
		if (weight <= 0) {
			throw new IllegalArgumentException("weight must be positive");	
		}
		this.name = name;
		this.age = age;
		this.weight = weight;
	}
	
	/**
	 * Returns the name of this person
	 * @return name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Returns the age of this person
	 * @return age
	 */
	public int getAge() {
		return this.age;
	}
	
	/**
	 * Returns the weight of this person
	 * @return age
	 */
	public int getWeight() {
		return this.weight;
	}
	
	/**
	 * Lets this person become one year older
	 */
	public void celebrateBirthday() {
		System.out.println("Let's party!");
		this.age += 1;
	}
	
	/**
	 * Returns a String representation of this person
	 */
	public String toString() {
		return "(Person: " + this.getName() + "," + this.getAge() + ")";
	}
	
}
