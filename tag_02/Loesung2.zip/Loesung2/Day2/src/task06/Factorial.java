package task06;

public class Factorial {

   public static void main (String[] args) {

      int n = 7;
      int product = 1;

      for (int i = 1; i <= n; i++) {
         product = product * i;
      }
      
      int factorial = product;

      System.out.println("n= " + n + ", n!= " + factorial);


      /* 
       * 'int' vs. 'long' als Datentyp
       *
       * bei 'int Factorial' ist die Ausgabe:
       *    n=17, n!=-288522240
       * --> die Zahl ist zu gross fuer 32 Bit und es gibt einen Ueberlauf
       * 
       * bei 'long Factorial' ist die Ausgabe:
       *    n=17, n!=355687428096000
       * --> 64 Bit reichen aus, um die Zahl korrekt darzustellen
	   */
   }

}
