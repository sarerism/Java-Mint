package task04;

public class TenNumbers {

	public static void main (String[] args) {

		int k; // used in while loops

		// %%%%%%%%%%%%%%%%%%%%%%%%%%

		// 10, 9, 8, 7, ..., 1 [for]
		for (int i=10; i>=1; i--) {
			System.out.print(i + " ");
		}
		System.out.println();

		// 10, 9, 8, 7, ..., 1 [while]
		k = 10;
		while ( k >= 1 ) {
			System.out.print(k + " ");
			k--;
		}
		System.out.println();

		// 10, 9, 8, 7, ..., 1 [for 1..10]
		for (int i=1; i<=10; i++) {
			System.out.print((11-i) + " ");
		}
		System.out.println();

		// %%%%%%%%%%%%%%%%%%%%%%%%%%

		// 100, 90, 80, 70, ..., 10 [for]
		for (int i=100; i>0; i=i-10) {
			System.out.print(i + " ");
		}
		System.out.println();

		// 100, 90, 80, 70, ..., 10 [while]
		k = 100;
		while ( k >= 1 ) {
			System.out.print(k + " ");
			k = k - 10;
		}
		System.out.println();

		// 100, 90, 80, 70, ..., 10 [for 1..10]
		for (int i=1; i<=10; i++) {
			System.out.print((110-i*10) + " ");
		}
		System.out.println();

		// %%%%%%%%%%%%%%%%%%%%%%%%%%

		// 0, 2, 4, ..., 18 [for]
		for (int i=0; i<19; i=i+2) {
			System.out.print(i + " ");
		}
		System.out.println();

		// 0, 2, 4, ..., 18 [while]
		k = 0;
		while ( k < 19 ) {
			System.out.print(k + " ");
			k = k + 2;
		}
		System.out.println();

		// 0, 2, 4, ..., 18 [for 1..10]
		for (int i=1; i<=10; i++) {
			System.out.print(((i-1)*2) + " ");
		}
		System.out.println();

		// %%%%%%%%%%%%%%%%%%%%%%%%%%

		// 20, 17, 14, ..., 2, -1, -4, -7 [for]
		for (int i=20; i>=-7; i=i-3) {
			System.out.print(i + " ");
		}
		System.out.println();

		// 20, 17, 14, ..., 2, -1, -4, -7  [while]
		k = 20;
		while ( k > -8 ) {
			System.out.print(k + " ");
			k = k - 3;
		}
		System.out.println();

		// 20, 17, 14, ..., 2, -1, -4, -7 [for 1..10]
		for (int i=1; i<=10; i++) {
			System.out.print((23-(i*3)) + " ");
		}
		System.out.println();

		// %%%%%%%%%%%%%%%%%%%%%%%%%%

		// 1, 4, 9, 16, 25, 36, ..., 81, 100 [for]
		for (int i=1; i<11; i++) {
			System.out.print((i*i) + " ");
		}
		System.out.println();

		// 1, 4, 9, 16, 25, 36, ..., 81, 100 [while]
		k = 1;
		while ( k < 11 ) {
			int quadrat = k*k;
			System.out.print(quadrat + " ");
			k = k + 1;
		}
		System.out.println();

		// 1, 4, 9, 16, 25, 36, ..., 81, 100 [for 1..10]
		for (int i=1; i<=10; i++) {
			System.out.print((i*i) + " ");
		}
		System.out.println();
		
		// %%%%%%%%%%%%%%%%%%%%%%%%%%

		// 1 2 6 7 11 12 16 17 21 22 [for]
		for (int i=1; i<22; i=i+5) {
			System.out.print(i + " ");
			System.out.print((i+1) + " ");
		}
		System.out.println();

		// 1 2 6 7 11 12 16 17 21 22 [while]
		k = 1;
		while ( k <= 21 ) {
			System.out.print(k + " ");
			System.out.print((k+1) + " ");
			k = k + 5;
		}
		System.out.println();

		// 1 2 6 7 11 12 16 17 21 22 [for 1..10]
		for (int i=1; i<=10; i++) {
			if(i%2!=0){ 
				System.out.print(5*(i-1)/2+1 + " "); 
			}
			else { 
				System.out.print(5*(i-2)/2+2 + " "); 
			} 
		}
		System.out.println();

		// %%%%%%%%%%%%%%%%%%%%%%%%%%
		
	}

}
