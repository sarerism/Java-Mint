package task12;

public class Fibonacci {

   public static void main (String[] args) {

      int summand1 = 0;
      System.out.print("The " + 0 + ". fibonacci number is " + summand1);
      int summand2 = 1;
      System.out.print("The " + 1 + ". fibonacci number is " + summand2);
      
      int fibonacci;

      for (int n=2; n<=50; n++) {

         // Calculate current Fibonacci number: F(n) = F(n-1) + F(n-2)
         fibonacci = summand1 + summand2;
         System.out.println("The " + n + ". fibonacci number is " + fibonacci);

         // Prepare for next loop
         summand1 = summand2; // F(n-1) is F(n-2) for next calculation
         summand2 = fibonacci;  // F(n) is F(n-1) for next calculation
      }



      /* 
       * Achtung: 
       * Bei der 48. Fibonacci-Zahl werden die Zahlen zu gross fuer 'int':
       * Die 46. Fibonacci-Zahl ist: 1134903170
       * Die 47. Fibonacci-Zahl ist: 1836311903
       * Die 48. Fibonacci-Zahl ist: -1323752223  (Ueberlauf)
       */
   }

}
