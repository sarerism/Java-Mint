package task11;

public class CalculationOfPi {

   public static void main (String[] args) {

      int numberOfSummands = 100;
      double approximationToPI = 0;


      for (int i = 0; i <= numberOfSummands; i++) {
         approximationToPI = approximationToPI + 4*( Math.pow(-1,i) / (2.0*i+1.0) );
      }

      System.out.println("numberOfSummands= " + numberOfSummands);
      System.out.println("pi ~= " + approximationToPI);
   }

}
