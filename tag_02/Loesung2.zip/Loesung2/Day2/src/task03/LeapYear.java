package task03;


public class LeapYear {

   public static void main (String[] args) {

      int year = 2012;

      // a)

      if ( year % 4 == 0) { 
         if ( year % 100 == 0 ) { 
            if (year % 400 == 0) { 
               System.out.println("The year " + year + " is a leap year.");
            } else { 
               System.out.println("The year " + year + " is NOT a leap year.");
            }
         } else { 
            System.out.println("The year " + year + " ist ein Schaltyear.");
         }
      } else { 
         System.out.println("The year " + year + " is NOT a leap year.");
      }


      // b)
      
      boolean isLeapYear = ( (year % 4 == 0)  && !(year % 100 == 0) ) || (year % 400 == 0);
      
      if ( isLeapYear ) {
            System.out.println("The year " + year + " ist ein Schaltyear.");
      } else {
            System.out.println("The year " + year + " is NOT a leap year.");
      }



   }

}
