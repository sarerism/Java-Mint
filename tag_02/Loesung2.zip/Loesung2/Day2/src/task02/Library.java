package task02;


public class Library {

   public static void main (String[] args) {

		int numberOfMonths = 2;
		boolean isReserved = false;
      
		if( numberOfMonths >= 5 || isReserved ) {
			System.out.println("The borrowing can be extended by another month");
		} else {
			System.out.println("You must return this book.");
		}



   }

}
