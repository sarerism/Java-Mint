package task09;

public class NoChange {

   public static void main(String[] args) {

      int numberOfCoins = 0;
      int numberOfNotes = 3;
      int price = 6;

      System.out.print("numberOfCoins = " + numberOfCoins + "; numberOfNotes = " + numberOfNotes + "; price = " + price + "; ");


      int numberOfNotesNeeded = price / 5;
      int remainingPrice;
      boolean enougthNotesPresent = (numberOfNotesNeeded <= numberOfNotes);
      
      if (enougthNotesPresent) {
          remainingPrice = price - 5*numberOfNotesNeeded;
      } else {
		  remainingPrice = price - 5*numberOfNotes;
	  }

      boolean canPayRemainingPrice = ( remainingPrice <= numberOfCoins );
      
      if (canPayRemainingPrice)  {
         System.out.println("YES");
      } else {
         System.out.println("NO");
      }



   }

}
