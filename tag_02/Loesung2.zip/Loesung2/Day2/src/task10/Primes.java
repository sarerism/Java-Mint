package task10;

public class Primes {

	public static void main(String[] args) {

        int highestNumber = 100;
        int numberOfPrimes = 0;

		// Test all numbers between 2 and highestNumber 
		for(int number=2; number <= highestNumber; number++) {
			
			boolean isPrime = true;
			
			// Check for dividers
			for(int divider=2; divider < number; divider++) {
				if( number % divider == 0 ) {
					isPrime = false;
				}
			}
			
			// Print primes
			if(isPrime) {
				numberOfPrimes++;
				System.out.print(number + " ");
			}
				
		}
		
		System.out.println();
		
		// Print percentage of primes
		double percentageOfPrimes = numberOfPrimes/(1.0*highestNumber);
		System.out.println(percentageOfPrimes);
			
	}

}


