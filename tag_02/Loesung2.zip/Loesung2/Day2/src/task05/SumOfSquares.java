package task05;

public class SumOfSquares {

   public static void main (String[] args) {

      int n = 100;
      int sumOfSquares = 0;

      for (int i = 1; i <= n; i++) {
         sumOfSquares = sumOfSquares + i*i;
      }

      System.out.println("n=" + n + ", sumOfSquares=" + sumOfSquares);
   }

}
