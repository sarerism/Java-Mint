package task01;

public class GreaterNumber {

   public static void main (String[] args) {

      int number1 = 2;
      int number2 = 3;
      System.out.println("number1 = " + number1 + "; number2 = " + number2 + ";");


      if ( number1 > number2 ) { 
         System.out.println("number1 is greater than number2.");
      } else if ( number2 > number1 ){
         System.out.println("number2 is greater than number1.");
      } else { 
         System.out.println("The numbers are the same size.");
      }


   }

}
