package task08;

public class EqualStrings {

   public static void main (String[] args) {

      String text1 = "Dog";
      String text2 = "Cat";
      String text3 = "Dog";
      System.out.println("Text1 = " + text1 + "; Text2 = " + text2 + "; Text3 = " + text3 + ";");

      if ( text1.equals(text2) && text1.equals(text3) ) {
		  System.out.println("All texts are equal.");
      }
	  else {
          if ( text1.equals(text2) || text1.equals(text3) || text2.equals(text3) ) { 
              System.out.println("Two of the texts are equal.");
          }
          else {
		      System.out.println("All texts are different.");
		  }
      }

   }

}
