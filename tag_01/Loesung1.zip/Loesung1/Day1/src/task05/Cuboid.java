package task05;

public class Cuboid {
   
   public static void main (String[] args) {

      double width = 2.0;
      double length = 4.0;
      double height = 6.0;

      double volume = width*length*height;
      System.out.println(volume);
      
      double surfaceArea = 2.0 * (width*length + width*height + length*height);
      System.out.println(surfaceArea);

      double diagonal = Math.sqrt(width*width + length*length + height*height);
      System.out.println(diagonal);

   }


}
