package task03;

public class Grades {

   public static void main (String[] args) {

      int gradeExam1 = 2;
      int gradeExam2 = 3;

      /* bad idea : division with integers 
       * 
       * int averageGrade = (gradeExam1 + gradeExam2) / 2;
       * System.out.println(averageGrade); // result: 2
       */

      double averageGrade = (gradeExam1 + gradeExam2) / 2.0;
      System.out.println(averageGrade); 

   }


}
