package task02;


public class Cars { 
	
		public static void main(String[] args) {
			
			int numberOfCars = 4;			
			numberOfCars = numberOfCars + 5;

			String typeOfCar = "Ferrari";
			
			System.out.println(numberOfCars + " " + typeOfCar + "s pass by");

			
		}
	
}
	   

		
