package task06;

public class TimeConversion {

   public static void main (String[] args) {

      // Start value: number of seconds
      int input = 7531; 

      // -------------------------------------
      // Solution 1 (minutes first)
      // -------------------------------------

      // 1 minute = 60 seconds
      int remainingMinutes = input / 60;
      int seconds = input % 60;

      // 1 hour = 60 minutes
      int remainingHours = remainingMinutes / 60;
      int minutes = remainingMinutes % 60;

      // 1 Tag = 24 Stunden
      int days = remainingHours / 24;
      int hours = remainingHours % 24;

      System.out.println(
         input + " seconds are "
         + days + " days, "
         + hours + " hours, "
         + minutes + " minutes and "
         + seconds + " seconds.");

      // -------------------------------------
      // Solution 2 (days first)
      // -------------------------------------

      // calculate complete days
      days = input / (60*60*24);
      int remainingSeconds = input % (60*60*24);

      // calculate complete hours
      hours = remainingSeconds / (60*60);
      remainingSeconds = remainingSeconds % (60*60);

      // caluclate complete minutes
      minutes = remainingSeconds / (60);
      seconds = remainingSeconds % (60);

      System.out.println(
         input + " seconds are "
         + days + " days, "
         + hours + " hours, "
         + minutes + " minutes and "
         + seconds + " seconds.");

   }


}
