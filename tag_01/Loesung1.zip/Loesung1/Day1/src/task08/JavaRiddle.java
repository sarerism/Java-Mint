package task08;

public class JavaRiddle {

   public static void main (String[] args) {

      // integer overflow
      int number1 = Integer.MAX_VALUE;
      System.out.println(number1); // = 2147483647
      number1 = number1 + 1;
      System.out.println(number1); // = -2147483648

      // division by 0
      double x = 1.0/0;
      System.out.println(x); // = Infinity

      // square root of -1
      double i = Math.sqrt(-1);
      System.out.println(i); // = NaN (Not a Number)

      // strange result
      System.out.println(1+2+"="+1+2); // 3=12
      
      // double overflow
      double number2 = Double.MAX_VALUE;
      System.out.println(number2); // = 1.7976931348623157E308
      number2 = number2 + number2;
      System.out.println(number2); // = Infinity

   }

}
