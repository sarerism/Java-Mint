package task04;

public class Swap {

   public static void main (String[] args) {

      double number1 = Math.random();
      double number2 = Math.random();
      
      System.out.println(number1 + " " + number2);
      
      // additional variable
      double tmp;
      
      // swap values
      tmp = number1;
      number1 = number2;
      number2 = tmp;
      
      System.out.println(number1 + " " + number2);

   }


}
