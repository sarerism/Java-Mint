package task01;


public class HelloEclipse { 
	
		public static void main(String[] args) {
			
			String name = "Anna";
			
			System.out.println("Hello " + name);

		}
	
}
	   

		
