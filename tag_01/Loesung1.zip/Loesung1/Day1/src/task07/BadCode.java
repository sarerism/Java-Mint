package task07;


public class BadCode { 
	
	public static void main (String[] args) { 
		
		int a, b;
		a = 5+4;
		b = 345; 
		
		int c=a+b;
		
		System.out.println("a="+a+","+"b"+'='+b); 
		System.out.println("a+b="+c);
		
	}
	
}
	   

		
