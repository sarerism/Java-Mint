package task09;

public class Puzzle {

   public static void main (String[] args) {

      /*
       * Zur Verstaendlichkeit behalten wir die Variablennamen aus der
       * Aufgabenstellung. Man koennte jedoch bessere Namen waehlen als 
       * nur x, y, x2, y2, f, z. 
       * /

      /*
      int l;
      int x = 4; int y = 4; int x2 =
      5; x = x    -1;
      int a = x;
      */
      // int l; // wird nur einmal fuer ein Zwischenergebnis verwendet, kann weg
      int x = 3; // s.u.
      int y = 4;
      int x2 = 5;
      // x = x-1; // Habe 'x' direkt auf 3 gesetzt
      // int a = x; // Ist dasselbe wie 'x', kann weg.
      // Alle Vorkommen von 'a' werden im Folgenden auf 'x' geaendert

      /*
      l = a-y; int y2 = (a-(y))*l;
      int f = ((a+y)    * (x+ y)) // *3
      +y2; int f2=(a+y)  *(((x+y)));
      f = f / 2//;
      ; double z = Math.pow(x2,2);
      */
      int y2 = (x-y) * (x-y);
      int f = ((x+y) * (x+y)) + y2; // Das +y2 gehoert dazu!!!
      // int f2 = (a+y)*(x+y); // Wird nie verwendet, kann weg
      f = f / 2;
      double z = Math.pow(x2,2);

      System.out.println ( f  + " == " + z + " " + (f==z) );
      System.out.println ( " z " );

      // Das Programm berechnet eine komplizierte Variante des
      // Satzes von Pythagoras (a*a + b*b = c*c)

   }

}
