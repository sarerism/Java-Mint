package task05;

/*
 * This Java-Program solves the problem
 * with 10000 peaople using an array
 */
public class People {

	public static void main(String[] args) {
		
		/*
		 * At first, all persons are present
		 */
		boolean[] personPresent = new boolean[10000];
		for( int j=0; j<10000; j++ ) {
			personPresent[j] = true;
		}
		
		int numberOfRemainingPersons = 10000;
		int counter = 0;
		int i=0;
		
		/*
		 * Count to 3 
		 * as long as there are more than 2 persons
		 */
		while( numberOfRemainingPersons > 2 ) {
					
			if(personPresent[i] && counter < 2) {
				counter++;
			} else if(personPresent[i] && counter == 2) {
				personPresent[i] = false;
				numberOfRemainingPersons--;
				counter = 0;
			}
			
			/*
			 * Increase loop variable
			 * But go back to 0 if 9999 is reached
			 */
			i++;
			i = i%10000;
		}
		
		/*
		 * Find remaining 2 persons
		 */
		for(int j=0; j<10000; j++ ) {
			if(personPresent[j]) {
				// index starts at 0, numbers start at 1
				int numberOfPerson = j+1;
				System.out.println(numberOfPerson);
			}
		}
		
		
	}
	
}
