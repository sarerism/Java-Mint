package task05;

import java.util.ArrayList;

/*
 * This Java-Program solves the problem
 * with 10000 people using a list
 */
public class Persons {

	public static void main(String[] args) {
		
		ArrayList<Integer> remainingPersons = new ArrayList<Integer>();
		
		/*
		 * Add all persons to the list with their respective numbers
		 */
		for (int i = 1 ; i <= 10000 ; i++) {
			remainingPersons.add(i);
		}
		
		int index = 0;
		
		/*
		 * Remove persons
		 * as long as there are more than 2 persons
		 */
		while (remainingPersons.size() > 2) {
			
			/*
			 * If a person is removed, the following
			 * persons are "moved up", hence "-1"
			 */
			index = index + 3 - 1;
			
			/*
			 * Go back to beginning when end of list is reached
			 */
			if (index >= remainingPersons.size()) {
				index = index - remainingPersons.size() ;
			}
			
			/*
			 * Remove person
			 */
			remainingPersons.remove(index);
		}
		
		/*
		 * Print remaining persons
		 */
		System.out.println(remainingPersons);

	}

}
