package task03;

/**
 * This class represents a student with
 * name, age, matriiculationNumber and course
 */
public class Student {

	private String name;
	private int age;
	private int matriculationNumber;
	private String course;
	
	/**
	 * Initializes a newly created Student object
	 **/
	public Student(String name, int age, int matriculationNumber, String course) {
		this.name = name;
		this.age = age;
		this.matriculationNumber = matriculationNumber;
		this.course = course;
	}
	
	/**
	 * Returns the name of this student
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Returns the age of this student
	 */
	public int getAge() {
		return age;
	}
	
	/**
	 * Returns the matriculationNumber of this student
	 */
	public int getMatriculationNumber() {
		return matriculationNumber;
	}
	
	/**
	 * Returns the course of this student
	 */
	public String getCourse() {
		return course;
	}
	
	/**
	 * Compares this Student object to the Student object given
	 * @param student
	 * @return true iff all values are identical
	 */
	public boolean equals(Student student) {
		boolean result = false;
		boolean equalNames = this.getName().equals(student.getName());
		boolean equalAge = ( this.getAge() == student.getAge() );
		boolean equalmatriculationNumber = ( this.getMatriculationNumber() == student.getMatriculationNumber() );
		boolean equalCourse = this.getCourse().equals(student.getCourse());
		if(equalNames && equalAge && equalmatriculationNumber && equalCourse) {
			result = true;
		}
		return result;
	}

	/**
	 * Returns a String represntation of this Student object
	 */
	public String toString() {
		String result = "Student: (";
		result += this.getName() + ",";
		result += this.getAge() + ",";
		result += this.getMatriculationNumber() + ",";
		result += this.getCourse() + ")";
		return result;
	}
	
	
	
}
