package task03;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a database for Student objects
 */
public class Database {

	private List<Student> students;

	/**
	 * Initializes a newly created Database object
	 **/
	public Database() {
		this.students = new ArrayList<Student>();
	}
	
	/**
	 * Adds the student to this database
	 * if this student is not already present
	 */
	public void addStudent(Student student) {
		if(this.studentIsPresent(student)) {
			throw new IllegalArgumentException("Student is already in database");
		} else {
			this.students.add(student);
		}
	}
	
	/**
	 * Checks whether the student is already in this database
	 * @return true iff there is a student object in this
	 *     database that equals the student object given
	 */
	public boolean studentIsPresent(Student student) {
		boolean result = false;
		for(Student presentStudent : students) {
			if(presentStudent.equals(student)) {
				result = true;
			}
		}
		return result;
	}
	
	/**
	 * Removes the student given from this database
	 * but only if student is in this database
	 */
	public void removeStudent(Student student) {
		Student currentStudent;
		for (int i = 0; i < this.students.size(); i++) {
			currentStudent = this.students.get(i);
			if (currentStudent.equals(student)) {
				this.students.remove(i);
			}
		}
	}
	
	/**
	 * Returns the average age of the students
	 * in this database
	 */
	public int getAverageAge() {
		int sumOfAge = 0;
		for(Student student : students) {
			sumOfAge += student.getAge();
		}
		int numberOfStudents = students.size();
		int averageAge = sumOfAge / numberOfStudents;
		return averageAge;
	}
	
	/**
	 * Prints a String representation of this database
	 */
	public void print() {
		System.out.println("Database: [");
		for(Student student : students) {
			System.out.println("   " + student.toString());
		}
		System.out.println("]");
	}
	
	/**
	 * Sorts this database according to the names
	 * of the students
	 */
	public void sort() {
		String name1 = "";
		String name2 = "";
		Student tmp;
		for(int i=0; i < students.size(); i++) {
			for(int j=0; j < students.size() -1; j++) {
				name1 = students.get(j).getName();
				name2 = students.get(j+1).getName();
				if(name1.compareTo(name2) > 0) {
					tmp = students.get(j);
					students.set(j, students.get(j+1));
					students.set(j+1,tmp);
				}
			}
		}
	}
	
}
