package task03;

public class Test {

	public static void main(String[] args) {
		
		/* Test for Student */
		Student paul = new Student("Paul",20,1234,"informatics");
		Student paula = new Student("Paula",20,1235,"informatics");
		
		System.out.println(paul.toString());
		System.out.println("Paul equals Paula? : " + paul.equals(paula));
		
		/* Test for Database */
		Student ronnie = new Student("Ronnie",25,2345,"informatics");
		Student tiffany = new Student("Tiffany",19,1267,"informatics");
		Student bernie = new Student("Bernie",21,2347,"informatics");
		
		Database database = new Database();
		database.addStudent(paul);
		database.addStudent(paula);
		database.addStudent(ronnie);
		database.addStudent(tiffany);
		database.addStudent(bernie);
		
		// database.addStudent(bernie); // should throw exception
		
		database.sort();
		database.print();

	}

}
