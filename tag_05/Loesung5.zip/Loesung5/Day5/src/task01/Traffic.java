package task01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Traffic {

	public static void main(String[] args) {

		/*
		 * Declare and fill list
		 */
		List<Integer> cars = Arrays.asList(3465, 3768, 4067, 3976, 4782, 2057, 2954);

		/*
		 * Print size
		 */
		System.out.println("Length of this list: " + cars.size());

		/*
		 * Print each element 
		 */
		for (int i = 0; i < cars.size(); i++) {
			System.out.println("element with index " + i + " is: " + cars.get(i));
		}
		for (Integer element : cars) {
			System.out.println(element);
		}

		/*
		 * Calculate average number of cars
		 */
		int sumOfAllCars = 0;
		for (Integer element : cars) {
			sumOfAllCars += element;
		}
		double averageNumberOfCars = sumOfAllCars / cars.size();
		System.out.println("The average number of cars is: " + averageNumberOfCars);

		/*
		 * Find day with maximum traffic
		 */
		int maximumCarsPerDay = 0;
		int day = 1;
		for (int i = 0; i < cars.size(); i++) {
			if (cars.get(i)> maximumCarsPerDay) {
				maximumCarsPerDay = cars.get(i);
				day = i + 1;
			}
		}
		System.out.println("Day with maximum traffic: " + day);

		/*
		 * Swap two values
		 */
		System.out.println("Swap values");
		int tmp = cars.get(3);
		cars.set(3, cars.get(4));
		cars.set(4,tmp);
		System.out.println("Values of day 4 and 5 swapped: " + cars);

		/*
		 * Create new list with reverse order of elements
		 */
		List<Integer> reversed = new ArrayList<Integer>();
		for (int i = 0; i < cars.size(); i++) {
			reversed.add(cars.get(cars.size()-i-1));
		}
		System.out.println("Reversed list: " + reversed);

		/*
		 * Sort the list with bubblesort algorithm
		 */
		for(int i=0; i<cars.size(); i++) {
			for(int j=0; j<cars.size()-1; j++) {
				if(cars.get(j) > cars.get(j+1)) {
					tmp = cars.get(j);
					cars.set(j, cars.get(j+1));
					cars.set(j+1,tmp);
				}
			}
		}
		System.out.println("Sorted list: " + cars);
		

	}

}
