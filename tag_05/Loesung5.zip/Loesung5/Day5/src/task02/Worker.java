package task02;

/**
 * This class represents an abstract worker
 * with salary and working material
 */
public abstract class Worker {
	
	private double salary;
	private WorkingMaterial workingMaterial;
	
	/**
	 * Initializes a newly created Worker object
	 **/
	public Worker(double salary, WorkingMaterial workingMaterial) {
		if(salary < 0) {
			throw new IllegalArgumentException("salary must not be negative");
		} 
		this.salary = salary;
		this.workingMaterial = workingMaterial;
	}

	/**
	 * Returns the salary of this worker
	 */
	public double getSalary() {
		return salary;
	}
	
	/**
	 * Sets the salary of this worker
	 * @param salary must not be negative
	 */
	public void setSalary(double salary) {
		if(salary < 0) {
			throw new IllegalArgumentException("salary must not be negative");
		}
		this.salary = salary;
	}

	/**
	 * Returns the working material of this worker
	 */
	public WorkingMaterial getWorkingMaterial() {
		return workingMaterial;
	}

	/**
	 * Lets this worker perform his action
	 */
	public void performAction() {
		System.out.println("Working ...");
	}
	

}
