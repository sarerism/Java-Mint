package task02;

public class Painter extends Worker {

	public Painter(double salary) {
		super(salary,WorkingMaterial.PAINT);
	}
	
	@Override
	public void performAction() {
		super.performAction();
		System.out.println("painting a wall!");
	}
}
