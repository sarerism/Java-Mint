package task02;

import java.util.Arrays;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		
		Painter paul = new Painter(23);
		Carpenter paula = new Carpenter(18,105);
		Bricklayer ronnie = new Bricklayer(18);
		
		paul.performAction();
		paula.performAction();
		ronnie.performAction();
		
		ronnie.setSalary( ronnie.getSalary() + 5 );
		
		/* Alternative: */
		
		/*
		
		Worker paul = new Painter(23);
		Worker paula = new Carpenter(18,105);
		Worker ronnie = new Bricklayer(18);
		
		List<Worker> workers = Arrays.asList(paul, paula, ronnie);
		for(Worker worker : workers) {
			worker.performAction();
		}
		
		ronnie.setSalary( ronnie.getSalary() + 5 );
		
		*/

	}

}
