package task02;

public class Bricklayer extends Worker  {
	
	public Bricklayer(double salary) {
		super(salary,WorkingMaterial.BRICKS);
	}
	
	@Override
	public void performAction() {
		super.performAction();
		System.out.println("laying bricks!");
	}
}
