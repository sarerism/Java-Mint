package task02;

public enum WorkingMaterial {
	WOOD, PAINT, BRICKS
}
