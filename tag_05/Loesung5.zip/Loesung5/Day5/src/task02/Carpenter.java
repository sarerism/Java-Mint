package task02;

public class Carpenter extends Worker  {

	private int nails;
	
	public Carpenter(double salary, int nails) {
		super(salary,WorkingMaterial.WOOD);
		if(nails < 100 || nails >= 1000) {
			throw new IllegalArgumentException("number of nails must be between 100 and 1000");
		}
		this.nails = nails;
	}
	
	@Override
	public void performAction() {
		if(this.nails < 5) {
			throw new IllegalStateException("carpenter has not enough nails to perform his action.");
		}
		super.performAction();
		for(int i=0; i<5; i++) {
			System.out.println("hammering nails!");
			this.nails -= 1;
		}
	}
}
