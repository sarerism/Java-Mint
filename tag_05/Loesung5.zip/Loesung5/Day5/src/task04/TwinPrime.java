package task04;

import java.util.ArrayList;
import java.util.List;

public class TwinPrime {

	public static void main(String[] args) {

		List<Integer> primes = new ArrayList<Integer>();

		/* Find primes in the range from 2 to 200000 */
		for (int candidate = 2; candidate <= 200000; candidate++) {

			boolean isPossiblyPrime = true;
			int j = 0;
			int prime;

			/* Find prime as possible divisor  */
			while (j < primes.size() && isPossiblyPrime) {

				prime = primes.get(j);
				if (candidate % prime == 0) {
					isPossiblyPrime = false;
				}
				j++;
			}
			
			/* no divisor found. candidate is prime */
			if (isPossiblyPrime) {
				primes.add(candidate);
			}

		}
		
		/* Find twin primes and print them */
		int counter=0;
		for(int j=0; j<primes.size()-1; j++){
			if((primes.get(j+1)-primes.get(j)) == 2){
				counter++;
				System.out.println(counter + ".  " + primes.get(j) + ", " + primes.get(j+1));
			}
		}

	}

}
