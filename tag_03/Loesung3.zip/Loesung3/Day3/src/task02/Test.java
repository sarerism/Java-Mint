package task02;

public class Test {

	public static void main(String[] args) {

		Calculator calc = new Calculator();

		// Test calculator method
		double result1 = calc.divide(5, 0);
		        
	}

}
