package task02;

public class Calculator {

	/**
	 * Adds a and b
	 * 
	 * @param a first summand
	 * @param b second summand
	 * @return a+b
	 */
	public int add(int a, int b) {

		long along = a;
		long blong = b;
		long test = along+blong;
		if(test > Integer.MAX_VALUE || test < Integer.MIN_VALUE) {
			throw new IllegalArgumentException("Sum is too large for datatype int");
		}
		int result = a+b;
		return result;
	}
	
	/**
	 * Divides a by b
	 * 
	 * @param a dividend
	 * @param b divisor
	 * @return a/b
	 */
	public double divide(int a, int b) {

		if(b==0) {
			throw new IllegalArgumentException("Division by zero is not allowed");
		}
		double result = a / (b * 1.0);
		return result;
	}


}
