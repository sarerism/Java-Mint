package task04;

public class RecursiveCalculator {

	/**
	 * Calculates the sum of the two numbers
	 * 
	 * @param p first number
	 * @param q second number
	 * @return p+q
	 **/
	public int mystery(int p, int q) {
		if (p == 0) {
			return q;
		} else {
			return mystery(p - 1, q + 1);
		}
	}


	/**
	 * Calculates and prints the Hailstone numbers starting from n
	 * 
	 * @param n start value
	 **/
	public static void printHailstone(int n) {
		System.out.print(n + " ");
		if (n == 1) {
			System.out.println(".");
		} else if (n % 2 == 0) {
			printHailstone(n / 2);
		} else {
			printHailstone(3 * n + 1);
		}
	}


	/**
	 * Calculates the sum of all numbers from 1 to the given number
	 * 
	 * @param n largest summand
	 * @return 1+2+...+n
	 **/
	public int sum(int n) {
		if (n == 0) {
			return 0;
		} else {
			return n + sum(n - 1);
		}
	}

	/**
	 * Calculates the number of balls in a tetrahedron
	 * of the height n
	 * 
	 * @param n height of the tetrahedron
	 * @return number of balls 
	**/
	public int tetrahedron(int n) {
		if (n == 1) {
			return 1;
		} else {
			return tetrahedron(n - 1) + sum(n);
		}
	}

}
