package task04;

public class Test {

	public static void main(String[] args) {

		RecursiveCalculator calc = new RecursiveCalculator();

		// Test the mysterious function
		int result4 = calc.mystery(2, 4);
		System.out.println("mystery(2,4) is: " + result4);
		System.out.println();

		// Print Hailstone numbers starting from different values
		System.out.println("Hailstone Numbers: ");
		calc.printHailstone(3);
		System.out.println("Hailstone Numbers: ");
		calc.printHailstone(6);
		System.out.println("Hailstone Numbers: ");
		calc.printHailstone(19);
		System.out.println();

		// Print tetrahedron numbers
		System.out.println("Tetrahedron numbers");
		System.out.println(calc.tetrahedron(1));
		System.out.println(calc.tetrahedron(2));
		System.out.println(calc.tetrahedron(3));
		System.out.println(calc.tetrahedron(4));
		System.out.println();

	}
}
