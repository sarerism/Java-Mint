package task07;

public class Test {

	public static void main(String[] args) {

		Hanoi hanoi = new Hanoi();
		
		// "A", "B", "C" are the names of the piles.
		hanoi.moveTower(4, "A", "B", "C"); 


	}

}
