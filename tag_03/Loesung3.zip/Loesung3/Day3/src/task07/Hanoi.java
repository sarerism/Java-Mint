package task07;

public class Hanoi {


	/**
	 * Move a tower of given height from one pile (from) to another (to)
	 *
	 * @param height the height of the tower which shall be moved
	 * @param from   the pile on which the tower is located in the beginning
	 * @param to     the pile on which the tower shall be in the end
	 * @param help   the third pile
	 */
	public void moveTower(int height, String from, String to, String help) {
		if (height == 1) {
			// basic case: move only one piece
			System.out.println("Lege die oberste Scheibe von Pfosten " + from + " auf Pfosten " + to);
		} else {
			// divide into sub-problems:

			// 1. move tower of height k-1 to the help pile
			moveTower(height - 1, from, help, to);

			// 2. move remaining piece to the final pile
			moveTower(1, from, to, help);

			// 3. move tower of height k-1 to the final pile
			moveTower(height - 1, help, to, from);
		}

	}

}
