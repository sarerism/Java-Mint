package task06;

public class Converter {

	
	/**
	 * Convert decimal number to binary representation
	 * 
	 * @param number the number to be converted
	 * @return number in binary system
	 */
	public String decimalToBinary(int number) {

		String binaryNumber = "";
		String digit;

		int quotient = number;
		int rest;

		while (quotient != 0) {
			rest = quotient % 2;
			quotient = quotient / 2;
			digit = Integer.toString(rest);
			binaryNumber = digit + binaryNumber;
		}

		return binaryNumber;
	}

	/**
	 * Convert decimal number to hexadecimal representation
	 * 
	 * @param number the number to be converted
	 * @return number in hexadecimal system
	 */

	public static String decimalToHex(int number) {

		String hexadecimalNumber = "";
		String digit;

		int quotient = number;
		int rest;

		while (quotient != 0) {

			rest = quotient % 16;
			quotient = quotient / 16;

			switch (rest) {
			case 10:
				digit = "A";
				break;
			case 11:
				digit = "B";
				break;
			case 12:
				digit = "C";
				break;
			case 13:
				digit = "D";
				break;
			case 14:
				digit = "E";
				break;
			case 15:
				digit = "F";
				break;
			default:
				digit = Integer.toString(rest);
			}

			hexadecimalNumber = digit + hexadecimalNumber;
		}

		return hexadecimalNumber;
	}


}
