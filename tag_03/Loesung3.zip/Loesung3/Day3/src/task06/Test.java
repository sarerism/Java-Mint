package task06;

public class Test {

	public static void main(String[] args) {

		Converter converter = new Converter();
	
		System.out.println("28 in binary system: " + converter.decimalToBinary(28));
		System.out.println("28 in hexadecimal system: " + converter.decimalToHex(28));

	}

}
