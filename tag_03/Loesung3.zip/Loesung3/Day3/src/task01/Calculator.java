package task01;

public class Calculator {

	/* Part 1 */

	/**
	 * Adds a and b
	 * 
	 * @param a first summand
	 * @param b second summand
	 * @return a+b
	 */
	public int add(int a, int b) {

		int result = a + b;
		return result;
	}

	/**
	 * Divides a by b
	 * 
	 * @param a dividend
	 * @param b divisor
	 * @return a/b
	 */
	public double divide(int a, int b) {

		double result = a / (b * 1.0);
		return result;
	}

	/**
	 * Find the maximum of two numbers
	 * 
	 * @param n first number
	 * @param m second number
	 * @return the larger one of the two numbers
	 */
	public int max(int n, int m) {

		int maximum = 0;

		if (n > m) {
			maximum = n;
		} else {
			maximum = m;
		}

		return maximum;

	}

	/**
	 * Find the maximum of three numbers
	 * 
	 * @param x first number
	 * @param y second number
	 * @param z third number
	 * @return the largest one of the numbers
	 */
	public int max(int x, int y, int z) {

		int maximumOfXandY = max(x, y);
		int maximum = max(maximumOfXandY, z);

		return maximum;

	}

	/**
	 * Prints a rectangle of the given size
	 * 
	 * @param height height of the rectange
	 * @param width width of the rectangle
	 */
	public void rectangle(int height, int width) {
		String oneLine = "";
		for (int j = 0; j < width; j++) {
			oneLine += "*";
		}
		for (int i = 0; i < height; i++) {
			System.out.println(oneLine);
		}
	}

	/**
	 * Prints a square of the given size
	 * 
	 * @param length length of one edge of the square
	 */
	public void square(int length) {
		this.rectangle(length, length);
	}

	/**
	 * Checks whether the given number n is prime
	 * 
	 * @param n positive integer number
	 * @return true iff n is prime
	 */
	public boolean isPrime(int n) {

		boolean result = true;

		// Check for dividers
		for (int divider = 2; divider < n; divider++) {
			if (n % divider == 0) {
				result = false;
			}
		}
		return result;
	}

	/* Part 2 */

	/**
	 * Calculates the square root using Heron's method with three iteration steps
	 * 
	 * @param a input number
	 * @return square root of a
	 */
	public double heron(double a) {

		double currentValue = a + 1;

		for (int i = 0; i < 3; i++) {
			currentValue = 0.5 * (currentValue + a / currentValue);
		}

		return currentValue;
	}

	/* Bonus Task */

	/**
	 * Calculates the square root using Heron's method
	 * 
	 * @param a input number
	 * @return square root of a
	 */
	public double heronExact(double a) {

		double currentValue = a + 1;
		double nextValue = a;

		while ((currentValue - nextValue) > 0.0) {
			currentValue = nextValue;
			nextValue = 0.5 * (currentValue + a / currentValue);
		}

		return nextValue;

	}

}
