package task01;

public class Test {

	public static void main(String[] args) {

		Calculator calc = new Calculator();

		// Test basic calculator methods
		double result1 = calc.divide(5, 6);
		System.out.println("5/6 is: " + result1);

		int result2 = calc.max(-3, 4);
		System.out.println("Maximum of -3 and 4 is: " + result2);

		int result3 = calc.max(3, 2, 1);
		System.out.println("Maximum of 3,2,1 is: " + result3);
		
		calc.rectangle(3,4);
		System.out.println();
		calc.square(2);
		
		boolean result5 = calc.isPrime(1001);
		System.out.println("Is 1001 prime? " + result5);
		

		System.out.println();

		// Print square roots of all numbers from 1 to 20
		// and the exact results using Math.sqrt()
		for (int i = 1; i <= 20; i++) {
			System.out.println(calc.heron(i)  + ", exact: " + Math.sqrt(i));
		}
		System.out.println();
	}
}
