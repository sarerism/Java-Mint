package task05;

public class Fibonacci {


	/**
	 * Calculates the n-th Fibonacci number recursively
	 */
	public double getNthNumber_r(int n) {
		if (n == 0) {
			return 0;
		} else if (n == 1) {
			return 1;
		} else {
			return getNthNumber_r(n - 1) + getNthNumber_r(n - 2);
		}
	}

	/**
	 * Calculates the n-th Fibonacci number using a for loop
	 */
	public double getNthNumber_i(int n) {
		double firstSummand = 0;
		double secondSummand = 1;
		double fibonacci = 1;
		if (n == 0) {
			return firstSummand;
		} else if (n == 1) {
			return secondSummand;
		} else {
			for (int i = 2; i <= n; i++) {
				fibonacci = secondSummand + firstSummand;
				firstSummand = secondSummand;
				secondSummand = fibonacci;
			}
			return fibonacci;
		}
	}
	
	/**
	 * Calculates the golden ratio
	 * with an accuracy of at least 7 digits
	 */
	public double calculatePhi() {
		double phiOld = getNthNumber_i(2) / getNthNumber_i(1);
		double phiNew = getNthNumber_i(3) / getNthNumber_i(2);
		int n = 3;
		while (Math.abs(phiOld - phiNew) > 1.0E-7) {
			phiOld = phiNew;
			phiNew = getNthNumber_i(n + 1) / getNthNumber_i(n);
			n++;
		}
		return phiNew;
	}

}
