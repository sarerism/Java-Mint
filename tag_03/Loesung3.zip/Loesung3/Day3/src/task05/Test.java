package task05;

public class Test {

	public static void main(String[] args) {

		
		Fibonacci fibonacci = new Fibonacci();

		long t1=0;
		long t2=0;

		t1 = System.currentTimeMillis();
		System.out.println(fibonacci.getNthNumber_r(42));
		t2 = System.currentTimeMillis();
		System.out.println("Time needed using rekursive calculation: " + (t2 - t1) + " ms");

		t1 = System.currentTimeMillis();
		System.out.println(fibonacci.getNthNumber_i(42));
		t2 = System.currentTimeMillis();
		System.out.println("Time needed using iterative calculation: " + (t2 - t1) + " ms");
		
		System.out.println("Phi = " + fibonacci.calculatePhi());


	}

}
