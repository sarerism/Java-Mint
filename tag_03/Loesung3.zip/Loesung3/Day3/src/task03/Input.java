package task03;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Input {

	public static void main(String[] args) {	
		
		Scanner scanner = new Scanner(System.in);
        int input = 0;   
        boolean exceptionOccured = true;
        
        while (exceptionOccured) {

        	exceptionOccured = false;

            try {
            	System.out.println("Please insert an integer number:");
                input = scanner.nextInt();
                System.out.println("Your input was: " + input);
                
            } catch (InputMismatchException e) {
                System.out.println("Wrong Input. Please try again: ");
                exceptionOccured = true;
                scanner.nextLine();
            }
        }
        
        
	}

}
